Sae demo说明文档
------------------
作者：毕成功(@毕成功passover)
时间：2012-4-17


项目说明
=========
    这是一个在sae上使用了spring2.5 + structs2 + ibatis2.3.4的demo，数据采用了json形式返回。
    自己在学习过程中花了不少时间，为了帮助大家节约sae中java开发的学习成本，并省去建立测试项目的繁琐工作，所以特别把自己测试工程整理成demo并发布。
    祝大家使用愉快！如果发现该demo的问题，可以用新浪微博（@毕成功passover）给我留言。


使用说明
=========
  1. 为了减小war包大小好上传到论坛，lib都已经删除，如果想运行可以自行添加，本demo用到的lib有：
aopalliance-1.0.jar            freemarker-2.3.18.jar
asm-3.3.jar                    gson-2.1.jar
asm-commons-3.3.jar            ibatis-2.3.4.726.jar
asm-tree-3.3.jar               javassist-3.11.0.GA.jar
aspectjweaver.jar              log4j.jar
c3p0-0.9.1.2.jar               mysql-connector-java-5.1.19-bin.jar
cglib-2.2.2.jar                ognl-3.0.4.jar
commons-codec-1.4.jar          sae-local-1.0.jar
commons-collections-3.2.1.jar  spring.jar
commons-fileupload-1.2.2.jar   struts2-convention-plugin-2.3.1.2.jar
commons-io-1.3.2.jar           struts2-core-2.3.1.2.jar
commons-lang-2.6.jar           struts2-spring-plugin-2.3.1.2.jar
commons-logging-1.1.1.jar      xwork-core-2.3.1.2.jar
derby.jar

  2. 添加servlet-api-2.5.jar到classpath中，可以在eclipse里面Java Build Path -> add library -> server runtime里面加。
     重点是注意，最后打war包的时候必须把这个jar给删掉，否则部署到sae上报错。
  
  3. 修改db.properties文件为你的应用对应信息
  
  4. 打出war包，并通过svn将其上传，参考http://sae.sina.com.cn/?m=devcenter&catId=212
  
  5. 在自己的sae应用里面打开mysql和kvdb的支持

  5. 程序部署后，先在日志中心看一下是否有报错，没有问题就把test_table.sql到数据库管理里面运行一下，建立相应的数据表和数据
  
  6. 程序部署后，可以先在日志中心看一下是否有报错，没有问题可以访问以下三个链接（{app_name}替换成你申请应用的app_name）
   * 测试数据库    http://{app_name}.sina.sinaapp.com/getTestValue
   * 测试数据库    http://{app_name}.sina.sinaapp.com/getFromMysql
   * 测试数据库    http://{app_name}.sina.sinaapp.com/getFromKV