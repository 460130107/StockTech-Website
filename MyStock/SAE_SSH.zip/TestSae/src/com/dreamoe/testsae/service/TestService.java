package com.dreamoe.testsae.service;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dreamoe.testsae.dao.TestDao;
import com.sina.sae.kvdb.KVUtil;
import com.sina.sae.kvdb.SaeKV;

@Service
public class TestService {
    
    private boolean isInit = false;
    private SaeKV kv;
    
    @Autowired
    private TestDao testDao;
    
    public String getFromMysql() {
//        String sql = "SELECT * FROM test";
//        //通过SaeUserInfo提供的静态方法获取应用的access_key和secret_key
//        String URL="jdbc:mysql://r.rdc.sae.sina.com.cn:3307/app_xxx";//使用从库的域名
//        String Username=SaeUserInfo.getAccessKey();
//        String Password=SaeUserInfo.getSecretKey();
////        String URL="jdbc:mysql://mini.sae.sina.com.cn:3306/app_xxx";//使用本地数据库
////        String Username="minisae";
////        String Password="minisae";
//        String Driver="com.mysql.jdbc.Driver";
//        String result = "";
//        try {
//            Class.forName(Driver).newInstance();
//            Connection con=DriverManager.getConnection(URL,Username,Password);
//            Statement statement = con.createStatement();
//            ResultSet rs = statement.executeQuery(sql);
//            while(rs.next()) {
//                int int1 = rs.getInt(1);
//                String s2 = rs.getString(2);
//                result += int1 + s2 + "\r\n";
//            }
//        } catch (InstantiationException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (IllegalAccessException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (ClassNotFoundException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
        return testDao.findStr();
    }
    
    public String getFromKV() {
        if(!isInit) {
            kv = new SaeKV();
            try {
                kv.init();
                kv.set("key", KVUtil.serializable("kv-value"));
                isInit = true;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        Object obj = kv.get("key");
        return obj.toString();
    }

}
