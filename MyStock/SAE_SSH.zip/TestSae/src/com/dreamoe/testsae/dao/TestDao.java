package com.dreamoe.testsae.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.ibatis.SqlMapClientTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class TestDao {

    @Autowired
    private SqlMapClientTemplate sqlMapClientTemplate;
    
    public String findStr() {
        return (String) sqlMapClientTemplate.queryForObject("findStr");
    }
    
}
