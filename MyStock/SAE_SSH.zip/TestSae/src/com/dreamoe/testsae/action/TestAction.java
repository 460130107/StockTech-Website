package com.dreamoe.testsae.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.dreamoe.testsae.domain.TestBean;
import com.dreamoe.testsae.service.TestService;
import com.google.gson.Gson;
import com.opensymphony.xwork2.ActionSupport;

@SuppressWarnings("serial")
@Controller
public class TestAction extends ActionSupport {
    
    @Autowired
    private TestService testService;
    
    private Gson gson = new Gson();
    
    @Action("/getTestValue")
    public String getTestValue() {
        TestBean tb = new TestBean();
        tb.setName("testname");
        tb.setAge("123");
        HttpServletResponse response = ServletActionContext.getResponse();
        PrintWriter pw;
        try {
            pw = response.getWriter();
            pw.write(gson.toJson(tb));
            pw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    @Action("/getFromMysql")
    public String getFromMysql() {
        HttpServletResponse response = ServletActionContext.getResponse();
        PrintWriter pw;
        try {
            pw = response.getWriter();
            pw.write(gson.toJson(testService.getFromMysql()));
            pw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    @Action("/getFromKV")
    public String getFromKV() {
        HttpServletResponse response = ServletActionContext.getResponse();
        PrintWriter pw;
        try {
            pw = response.getWriter();
            pw.write(gson.toJson(testService.getFromKV()));
            pw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

}
